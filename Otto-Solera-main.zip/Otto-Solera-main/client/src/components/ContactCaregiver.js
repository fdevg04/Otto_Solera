// src/components/ContactCaregiver.js
import React from 'react';
import "../styles/ContactCaregiver.css";

const ContactCaregiver = () => {
  return (
    <div>
      <h2>Contactar con un Cuidador</h2>
      {/* Aquí puedes agregar la funcionalidad para que el beneficiario contacte con un cuidador */}
    </div>
  );
};

export default ContactCaregiver;
